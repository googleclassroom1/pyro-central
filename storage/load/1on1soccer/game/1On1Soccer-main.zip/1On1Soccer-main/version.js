version="25";
libs=["patch/cdn/phaser/phaser-ads.min.js","patch/cdn/phaser/phaser-cachebuster.min.js","patch/cdn/phaser/phaser-spine.min.js","patch/cdn/kizi/splash.js"];